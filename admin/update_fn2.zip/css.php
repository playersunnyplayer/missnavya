<!-- App favicon -->
<!--<link rel="shortcut icon" href="assets/images/favicon.png">-->
<link href="assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
<!-- Bootstrap Css -->
<link href="bootstrap.php?a=#AC286B" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
<link href="assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="app.min.php?a=#AC286B" id="app-style" rel="stylesheet" type="text/css" />
