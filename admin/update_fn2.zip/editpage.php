<?php
ob_start();
session_start();
$adminId=$_SESSION['aid'];
include_once("configuration/connect.php");
include_once("configuration/functions.php");
if(isset($_SESSION["aid"])) {
if(isLoginSessionExpired()) {
header("Location:logout.php");
}
}
$date=date('d-m-Y h:i:sa');
checkIntrusion($adminId);
if(isset($_GET['pid'])&&$_GET['pid']!=''){
	$pid=base64_decode($_GET['pid']);
	$qry=mysqli_query($con,"select * from websitepage where id='$pid'");
	$fetch=mysqli_fetch_array($qry);
}
if(isset($_POST['addpage'])){
	extract($_POST);
	$id=$_POST['hidid'];
	$city=$_POST['pgname'];
	$url=strtolower($_POST['slug']);
	$content=$_POST['content'];
	$status=$_POST['sts'];
	$contact=$_POST['contact'];
	$email=$_POST['email'];
	$date=date('d-m-Y');
	$filename = date('YmdHis')."_".$_FILES['image2']['name'];
	$valid_ext = array('png','jpeg','jpg','ico');
	$location2="../assets/img/".$filename;
	$location = "../assets/img/".$filename;
	$file_extension = pathinfo($location, PATHINFO_EXTENSION);
	$file_extension = strtolower($file_extension);
	if(in_array($file_extension,$valid_ext)){
		compressImage($_FILES['image2']['tmp_name'],$location,60);
		}else{
		echo "Invalid file type.";
		}
		if($_FILES['image2']['name']!='') {
			$excQry=mysqli_query($con,"UPDATE `websitepage` SET `city`='$city',`url`='$url',`content`='$content',`image`='$filename',`contact`='$contact',`email`='$email',`status`='1',`date`='$date' where `id`='$id'");
		}else{
			$excQry=mysqli_query($con,"UPDATE `websitepage` SET `city`='$city',`url`='$url',`content`='$content',`contact`='$contact',`email`='$email',`status`='1',`date`='$date' where `id`='$id'");

		}
			if($excQry ){
			header("location:viewpage.php?msg=ups");
		}else{
			header("location:viewpage.php?msg=inf");
		}
	}
	if(isset($_GET['msg'])&&$_GET['msg']!=''){
	$msg=$_GET['msg'];
//	$name=getPageNameById(base64_decode($_GET['pid']));
	switch($msg){
	case 'ins':
	$msg='<strong>Success!</strong> City has been added Successfully !!';
	$class='success';
	break;

	case 'inf':
	$msg='Data not inserted Successfully !!';
	$class='danger';
	break;
	case 'url':
	$msg='City slug already used!!';
	$class='danger';
	break;
	case 'dlf':
	$msg='City not deleted !!';
	$class='danger';
	break;
	case 'dls':
	$msg= '<strong>Success!</strong> City Deleted Successfully !!';
	$class='success';
	break;
	case 'default' :
	$msg='';
	break;

	}
	}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Edit Page | <?php echo getSiteTitle(17); ?> </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php include 'css.php'; ?>
<script src="assets/libs/jquery/jquery.min.js"></script>
<script src="ckeditor/ckeditor.js"></script>
<style>
#sticky-div {
   position : fixed;
 /*bottom:0;*/

}
</style>
<script>
$counter =0;
//$a =0;
	// add code
		function addCode(ele)
		{
			$button = $(ele);
			// increment
			$counter += 1;
			$button.closest('tr').before('<tr><td><div  class="mb-3 col-lg-12"><label for="name">Title</label><input type="text"  name="pp['+$counter+'][title]" class="form-control"/></div><div  class="mb-3 col-lg-12"><label for="name">Content</label><textarea class="form-control" id="editor'+$counter+'" placeholder="Content" name="pp['+$counter+'][content]"></textarea></div><div style="text-align:right"><button class="btn btn-danger btn-md remove_code"  type="button" onClick="remove(this)">Remove section</button></div></td></tr>');
			var a="editor"+$counter;
			CKEDITOR.replace(a);
		}
		function remove(ele)
		{
			$button = $(ele);
			$button.closest('tr').remove();
			return false;
		}
</script>
<script>
function myFunction() {
  var x = document.getElementById("mySelect").value;
	window.location.href="dashboard.php?web="+x;
}
</script>
<script>
function readURL(input) {
		if (input.files && input.files[0]) {
				var reader = new FileReader();

				reader.onload = function (e) {
						$('#pimage')
								.attr('src', e.target.result);
				};

				reader.readAsDataURL(input.files[0]);
		}
}
</script>
</head>
<body >
<!-- Begin page -->
<div id="layout-wrapper">
<?php include 'header.php'; ?>
<!-- ========== Left Sidebar Start ========== -->
<?php include 'leftmenu.php'; ?>
<!-- Left Sidebar End -->
<div class="main-content">
<div class="page-content">
<div class="container-fluid">
<div class="row">
<div class="col-6">
<div class="page-title-box  align-items-center justify-content-between">
<h4 class="mb-3 font-size-18">Edit Page</h4>

                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                                           <li class="breadcrumb-item"> <a href="viewpage.php">Pages</a></li>
                                            <li class="breadcrumb-item active">Edit Page</li>
                                        </ol>


</div>
</div>
<div class="col-6" style="text-align:right">
    <div class="page-title-right ">
</div>
</div>
</div>
<?php if($msg!=''){ ?>
<div class="alert alert-<?php echo $class ?> alert-dismissible fade show" role="alert">
<?php echo $msg; ?>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php } ?>
<form id="myform" action="" method="post"   enctype="multipart/form-data">
<div class="row">
	<div class="mb-3 col-lg-2">
	<label for="slug">City <span style="color:red">*</span></label>
	<input type="text" placeholder="City name" required class="form-control" id="pgname" name="pgname" onKeyUp="fillPrintableName()" value="<?php echo $fetch['city'] ?>">
	<input type="hidden" placeholder="City name" class="form-control" id="hidid" name="hidid" value="<?php echo $fetch['id'] ?>">

	</div>
	<div  class="mb-3 col-lg-2">
	<label for="slug">Slug</label>
	<input style="text-transform:lowercase" readonly  type="text" id="slug" name="slug" class="form-control" value="<?php echo $fetch['url'] ?>"/>
	</div>
	<div class="mb-3 col-lg-3">
	<label for="slug">Page Contact <span style="color:red">*</span> </label><span style="float:right;text-align:right"> Default Contact<input type="checkbox" placeholder="contact"   id="contact_chk" name="contact_chk" ></span>
	<input type="text" placeholder="contact" required class="form-control" id="contact" name="contact" value="<?php echo $fetch['contact'] ?>"/>
	<input type="hidden" id="default" name="defalut" value="<?php echo getContact(17) ?>">
	</div>
	<div class="mb-3 col-lg-3">
	<label for="slug">Page Email</label>
	<input type="email" placeholder="Email"  class="form-control" id="email" name="email" <?php echo $fetch['email'] ?> >
	</div>
	<div  class="mb-3 col-lg-2">
	<label for="order">Status</label>
	<select class="form-select" name="sts" id="sts">
		<option value="1">Publish</option>
		<option value="0">Save As Draft</option>
	</select>
	</div>
<div class="row">
<div class="card">
<div class="card-body">
<h4 class="card-title mb-4">Page Content </h4>
<div class="row">
<div  class="mb-3 col-md-8"><label for="name">Content <span style="color:red">*</span></label><textarea id="editor" name="content" class="form-control"><?php echo $fetch['content'] ?></textarea></div>
<div  class="mb-3 col-md-4"><label for="name">Image <span style="color:red">*</span></label>
	<br><img id="pimage" style="max-width: 100%;" src="../assets/img/<?php echo $fetch['image'] ?>"  alt="">
<input class="form-control form-control" id="image" type="file" name="image2" onchange="readURL(this);">
</div>
</div>
</div>
</div>
</div>
</div>
<div class="row">
	<div class="mb-3 col-md-12">
	<button type="submit" name="addpage" class="btn btn-success w-md btn-md">Update</button> <button type="button" onclick="goBack()"name="cancel" class="btn btn-outline-success btn-md w-md">Cancel</button>
	</div>
</div>
</div>
</form>
</div>
</div>

</div>
</div>
<?php include 'script.php'; ?>
<script src="assets/libs/select2/js/select2.min.js"></script>
<script src="assets/js/pages/form-advanced.init.js"></script>
<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="http://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
<script type="text/javascript">
function goBack() {
window.history.go(-1);
}
function fillPrintableName(){
	var fname=document.getElementById('pgname').value;
	var pname='Escort-in-'+fname;
var c=pname.replace(/\s/g, '-')
	var nameoncard =document.getElementById('slug');
	nameoncard.value=c;
}
$(document).ready(function() {
	$('#myform').validate({
		rules: {
		pgname: "required",
		contact: {
		number: true,
		minlength: 10,
		maxlength: 10
		},
		editor:"required"

		},
		messages: {
		name: "Please enter city",
		contact: {
		minlength: "Please enter 10 digit contact no",
		maxlength: "Please enter 10 digit contact no"
		},
		editor: "Please enter city content"


		},
	submitHandler: function(form) { // for demo
		form.submit();
	}
	});
	});
$(document).ready(function() {
    //set initial state.
    $('#contact_chk').val(this.checked);
		var df=  $('#default').val();
    $('#contact_chk').change(function() {
        if(this.checked) {

              $('#contact').val(df);
							$('#contact').prop('readonly', true);
        }else{$('#contact').prop('readonly', false);$('#contact').val('');}

    });
});
</script>
<script>
  CKEDITOR.replace( 'editor' );
</script>
</body>
</html>
