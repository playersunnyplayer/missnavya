<div class="vertical-menu">
<div data-simplebar class="h-100">
<div style="text-align:center;width:100px;height:100px;margin:20px auto 10px;overflow:hidden">
<img src="assets/images/miss-navya.png" alt="" style="width:100px">
</div>
<!--- Sidemenu -->
<div id="sidebar-menu">
<!-- Left Menu Start -->
<ul class="metismenu list-unstyled" id="side-menu">
<li><a href="dashboard.php" class="waves-effect"><i class="bx bxs-dashboard"></i><span key="t-pages">Dashboard</span></a></li>
<li><a href="websitesetting.php" class=" waves-effect"><i class='bx bxs-cog'></i><span key="t-layouts">Website Setting</span>  </a>  </li>
<li>
<a href="javascript: void(0);" class="has-arrow waves-effect">
<i class="bx bx-home"></i><span key="t-pages">Home Pages</span>
</a>
<ul class="sub-menu" aria-expanded="false">
  <li><a href="slider.php" key="t-product-detail">Slider Image</a></li>
<li><a href="section1.php" key="t-product-detail">Section 1</a></li>
<li><a href="section2.php" key="t-products">Section 2</a></li>
<li><a href="section3.php" key="t-products">Galary Section</a></li>
<li><a href="section4.php" key="t-products">Section 3</a></li>
</ul>
</li>
<li>
<a href="javascript: void(0);" class="has-arrow waves-effect">
<i class="bx bx-file"></i><span key="t-pages">Other Pages</span>
</a>
<ul class="sub-menu" aria-expanded="false">
<li><a href="viewpage.php" key="t-product-detail"> All Pages</a></li>
<li><a href="addpage.php" key="t-products">Add New</a></li>
</ul>
</li>
<li><a href="viewcontact.php" class=" waves-effect"><i class='bx bxs-phone'></i><span key="t-layouts">View Contact</span>  </a>  </li>
<li><a href="settings.php" class=" waves-effect"><i class='bx bxs-user'></i><span key="t-layouts">Setting</span>  </a>
<!--<li><a href="settings.php" key="t-products">  <i class="bx bx-cog"></i>Settings</a></li>-->
<li><a href="logout.php" key="t-product-detail">  <i class="bx bx-lock"></i>Log Out</a></li>
</ul>
</div>
<!-- Sidebar -->
</div>
</div>
